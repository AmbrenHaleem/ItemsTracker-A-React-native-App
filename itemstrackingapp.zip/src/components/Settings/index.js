import LocalNotification from "../LocalNotification";
import Preference from "./Preference";

export default function Settings(){
    return (
        <>
        <Preference />
        <LocalNotification />
        </>
        
    )
}